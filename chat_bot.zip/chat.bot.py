import logging
import random
from aiogram import Bot, Dispatcher, types
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.utils import executor

API_TOKEN = '7917602464:AAGRAzS5YrxbAga6Y6wn_VfpUZIdZqabJrs'

# Настройка логирования
logging.basicConfig(level=logging.INFO)

# Инициализация бота и диспетчера
bot = Bot(token=API_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.answer("Привет! Отправь мне текст или файл, и я проверю его на плагиат😈.")

@dp.message_handler(content_types=types.ContentTypes.TEXT)
async def check_plagiarism_text(message: types.Message):
    text = message.text
    await process_text(message, text)

@dp.message_handler(content_types=types.ContentTypes.DOCUMENT)
async def check_plagiarism_file(message: types.Message):
    document_id = message.document.file_id
    file = await bot.get_file(document_id)
    file_path = file.file_path

    downloaded_file = await bot.download_file(file_path)

    # Сохраняем файл на диск (по необходимости)
    with open(message.document.file_name, 'wb') as new_file:
        new_file.write(downloaded_file.getvalue())

    # Открываем файл и читаем его содержимое
    with open(message.document.file_name, 'r', encoding='utf-8') as file_content:
        text = file_content.read()
        await process_text(message, text)

async def process_text(message: types.Message, text: str):
    # Здесь вы вызываете функцию проверки плагиата
    is_plagiarized = check_plagiarism_fake(text)

    if is_plagiarized:
        await message.answer("🔍 Ваш текст содержит плагиат.")
    else:
        await message.answer("✅ Ваш текст уникален.")

def check_plagiarism_fake(text):
    # Имитация проверки текста на плагиат
    return random.choice([True, False])

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)