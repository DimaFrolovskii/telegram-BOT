import os
import psycopg2
from dotenv import load_dotenv
import hashlib

load_dotenv()

class Database:
    def __init__(self):
        self.conn = psycopg2.connect(
            host=os.getenv('DB_HOST'),
            database=os.getenv('DB_NAME'),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD'),
            port=os.getenv('DB_PORT')
        )
        self.create_tables()
    
    def create_tables(self):
        with self.conn.cursor() as cursor:
            # Создаем таблицы, если их нет
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS professors (
                    professor_id SERIAL PRIMARY KEY,
                    login VARCHAR(50) UNIQUE NOT NULL,
                    password_hash VARCHAR(255) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS groups (
                    group_id SERIAL PRIMARY KEY,
                    group_name VARCHAR(100) NOT NULL,
                    student_count INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS subjects (
                    subject_id SERIAL PRIMARY KEY,
                    subject_name VARCHAR(150) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS professor_groups (
                    professor_id INTEGER REFERENCES professors(professor_id) ON DELETE CASCADE,
                    group_id INTEGER REFERENCES groups(group_id) ON DELETE CASCADE,
                    PRIMARY KEY (professor_id, group_id)
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS files (
                    file_id SERIAL PRIMARY KEY,
                    original_name VARCHAR(255) NOT NULL,
                    content TEXT NOT NULL,
                    content_hash VARCHAR(64) NOT NULL,
                    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    professor_id INTEGER REFERENCES professors(professor_id) ON DELETE SET NULL,
                    group_id INTEGER REFERENCES groups(group_id) ON DELETE SET NULL,
                    subject_id INTEGER REFERENCES subjects(subject_id) ON DELETE SET NULL
                )
            """)
            self.conn.commit()
    
def add_professor(self, login, password):
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    with self.conn.cursor() as cursor:
        cursor.execute(
            "INSERT INTO professors (login, password_hash) VALUES (%s, %s) RETURNING professor_id",
            (login, password_hash)  # <-- Добавлена закрывающая скобка
        )  # Закрывающая скобка для execute
        professor_id = cursor.fetchone()[0]
        self.conn.commit()
        return professor_id
    
    def get_professor(self, login):
        with self.conn.cursor() as cursor:
            cursor.execute("SELECT * FROM professors WHERE login = %s", (login,))
            return cursor.fetchone()
    
    def add_group(self, group_name):
        with self.conn.cursor() as cursor:
            cursor.execute(
                "INSERT INTO groups (group_name) VALUES (%s) RETURNING group_id",
                (group_name,))
            group_id = cursor.fetchone()[0]
            self.conn.commit()
            return group_id
    
    def add_file(self, file_name, content, professor_id, group_id=None, subject_id=None):
        content_hash = hashlib.sha256(content.encode()).hexdigest()
        with self.conn.cursor() as cursor:
            cursor.execute(
                """INSERT INTO files 
                (original_name, content, content_hash, professor_id, group_id, subject_id) 
                VALUES (%s, %s, %s, %s, %s, %s) RETURNING file_id""",
                (file_name, content, content_hash, professor_id, group_id, subject_id)
            )
            file_id = cursor.fetchone()[0]
            self.conn.commit()
            return file_id
    
    def compare_files(self, content, group_id=None, subject_id=None):
        content_hash = hashlib.sha256(content.encode()).hexdigest()
        with self.conn.cursor() as cursor:
            query = """
                SELECT file_id, original_name, content 
                FROM files 
                WHERE content_hash = %s
            """
            params = [content_hash]
            
            if group_id:
                query += " AND group_id = %s"
                params.append(group_id)
            
            if subject_id:
                query += " AND subject_id = %s"
                params.append(subject_id)
            
            cursor.execute(query, params)
            return cursor.fetchall()
    
    def close(self):
        self.conn.close()

# Для тестирования
if __name__ == '__main__':
    db = Database()
    print("База данных инициализирована")
    prof_id = db.add_professor("teacher1", "password123")
    group_id = db.add_group("Группа А")
    file_id = db.add_file("test.txt", "Пример содержимого файла", prof_id, group_id)
    print(f"Добавлен профессор: {prof_id}, группа: {group_id}, файл: {file_id}")
    db.close()