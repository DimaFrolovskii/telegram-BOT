import os
import difflib
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Updater, CommandHandler, CallbackQueryHandler, 
    CallbackContext, MessageHandler, Filters
)
from pgadmin import Database
from dotenv import load_dotenv

load_dotenv()

# Инициализация базы данных
db = Database()

# Функции сравнения файлов
def compare_texts(text1, text2):
    """Сравнивает два текста и возвращает процент схожести"""
    seq_matcher = difflib.SequenceMatcher(None, text1, text2)
    return seq_matcher.ratio() * 100

def extract_text(file):
    """Извлекает текст из файла (базовый вариант)"""
    try:
        return file.get_file().download_as_bytearray().decode('utf-8')
    except Exception as e:
        print(f"Ошибка чтения файла: {e}")
        return ""

# Обработчики команд
def start(update: Update, context: CallbackContext):
    keyboard = [
        [InlineKeyboardButton("📄 Сравнить 2 файла", callback_data='compare')],
        [InlineKeyboardButton("🔍 Проверить на плагиат", callback_data='plagiarism')],
        [InlineKeyboardButton("👨‍🏫 Меню преподавателя", callback_data='professor')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text(
        '📚 Бот для проверки на плагиат\n\n'
        'Выберите действие:', 
        reply_markup=reply_markup
    )

def button_handler(update: Update, context: CallbackContext):
    query = update.callback_query
    query.answer()
    
    if query.data == 'compare':
        context.user_data['mode'] = 'compare'
        context.user_data['files'] = []
        query.edit_message_text("📤 Отправьте два файла для сравнения (по одному за раз). После отправки второго файла я сравню их.")
    
    elif query.data == 'plagiarism':
        context.user_data['mode'] = 'plagiarism'
        query.edit_message_text("📤 Отправьте файл для проверки на плагиат. Я сравню его с файлами в базе данных.")
    
    elif query.data == 'professor':
        professor_menu(update, context)

def professor_menu(update: Update, context: CallbackContext):
    query = update.callback_query
    keyboard = [
        [InlineKeyboardButton("➕ Добавить файл в базу", callback_data='add_file')],
        [InlineKeyboardButton("👥 Управление группами", callback_data='manage_groups')],
        [InlineKeyboardButton("📚 Управление предметами", callback_data='manage_subjects')],
        [InlineKeyboardButton("🔙 Назад", callback_data='back')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text("👨‍🏫 Меню преподавателя:", reply_markup=reply_markup)

def handle_document(update: Update, context: CallbackContext):
    user_data = context.user_data
    mode = user_data.get('mode')
    
    if not mode:
        update.message.reply_text("ℹ️ Пожалуйста, выберите действие через /start")
        return
    
    file = update.message.document
    file_name = file.file_name
    file_content = extract_text(file)
    
    if not file_content:
        update.message.reply_text("❌ Не удалось прочитать файл. Пожалуйста, отправьте текстовый файл.")
        return
    
    if mode == 'compare':
        if 'files' not in user_data:
            user_data['files'] = []
        
        user_data['files'].append((file_name, file_content))
        
        if len(user_data['files']) == 1:
            update.message.reply_text(f"✅ Файл {file_name} получен. Отправьте второй файл для сравнения.")
        elif len(user_data['files']) == 2:
            file1_name, file1_content = user_data['files'][0]
            file2_name, file2_content = user_data['files'][1]
            
            similarity = compare_texts(file1_content, file2_content)
            result = (
                f"📊 Результаты сравнения:\n"
                f"Файл 1: {file1_name}\n"
                f"Файл 2: {file2_name}\n\n"
                f"🔍 Процент схожести: {similarity:.2f}%\n\n"
            )
            
            if similarity > 70:
                result += "⚠️ Высокий процент совпадения! Возможен плагиат."
            elif similarity > 40:
                result += "ℹ️ Умеренный процент совпадения."
            else:
                result += "✅ Низкий процент совпадения."
            
            update.message.reply_text(result)
            del user_data['files']
            del user_data['mode']
    
    elif mode == 'plagiarism':
        # В реальном приложении здесь нужно запросить группу/предмет
        similar_files = db.compare_files(file_content)
        
        if not similar_files:
            update.message.reply_text("✅ Плагиат не обнаружен. Файл уникален.")
            return
        
        result = "🔍 Обнаружены похожие файлы:\n\n"
        for file_id, orig_name, content in similar_files:
            similarity = compare_texts(file_content, content)
            result += f"📄 Файл: {orig_name}\n🔢 ID: {file_id}\n📊 Сходство: {similarity:.2f}%\n\n"
        
        result += "⚠️ Если сходство высокое, возможно, это плагиат."
        update.message.reply_text(result)
        del user_data['mode']

def error_handler(update: Update, context: CallbackContext):
    """Логируем ошибки"""
    print(f"Ошибка: {context.error}")
    if update.message:
        update.message.reply_text("❌ Произошла ошибка. Пожалуйста, попробуйте еще раз.")

def main():
    TOKEN = os.getenv('TOKEN')
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher
    
    # Регистрируем обработчики
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CallbackQueryHandler(button_handler))
    dp.add_handler(MessageHandler(Filters.document, handle_document))
    dp.add_error_handler(error_handler)
    
    print("Бот запущен...")
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()