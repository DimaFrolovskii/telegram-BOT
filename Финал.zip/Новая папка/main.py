from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command, StateFilter
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from itertools import combinations
import logging
import re
import os
import asyncpg

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("bot_log.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

BOT_TOKEN = "7917602464:AAGRAzS5YrxbAga6Y6wn_VfpUZIdZqabJrs"
ADMIN_ID = [1225071404, 827550230, 1293669701, 1273520984]

DB_CONFIG = {
    "user": "bot",
    "password": "123321",
    "database": "telegram_bot_db",
    "host": "localhost",
    "port": 5432,
    "server_settings": {
        'search_path': 'public'
    }
}

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

class FileStates(StatesGroup):
    waiting_for_files = State()
    checking_files = State()
    teacher_menu = State()
    view_files = State()
    upload_teacher_files = State()
    delete_teacher_files = State()
    select_files_to_compare = State()
    support = State()

user_state_history = {}
user_message_history = {}

def get_main_kb(user_id: int) -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="Сравнить файлы"))
    if user_id in ADMIN_ID:
        builder.row(KeyboardButton(text="Преподаватель"))
    builder.row(KeyboardButton(text="Тех.Поддержка"))
    return builder.as_markup(resize_keyboard=True)

def get_upload_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="Завершить загрузку"))
    builder.row(KeyboardButton(text="🔙 Назад"))
    return builder.as_markup(resize_keyboard=True)

def get_check_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="Проверить"))
    builder.row(KeyboardButton(text="🔙 Назад"))
    return builder.as_markup(resize_keyboard=True)

def get_teacher_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="Посмотреть файлы"))
    builder.row(KeyboardButton(text="Загрузить файлы"))
    builder.row(KeyboardButton(text="Удалить файлы"))
    builder.row(KeyboardButton(text="Сравнить файлы (преподаватель)"))
    builder.row(KeyboardButton(text="🔙 Назад"))
    return builder.as_markup(resize_keyboard=True)

def get_back_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="🔙 Назад"))
    return builder.as_markup(resize_keyboard=True)

def get_support_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="🔙 Назад"))
    return builder.as_markup(resize_keyboard=True)

def get_files_selection_kb(files: list, selected_files: list = None) -> InlineKeyboardMarkup:
    if selected_files is None:
        selected_files = []
    
    builder = InlineKeyboardBuilder()
    for file in files:
        file_name = file['file_name']
        text = f"✅ {file_name}" if file_name in selected_files else file_name
        builder.add(InlineKeyboardButton(
            text=text,
            callback_data=f"sel:{file_name}"
        ))
    builder.adjust(1)
    builder.row(InlineKeyboardButton(
        text="Сравнить выбранные",
        callback_data="compare_selected"
    ))
    builder.row(InlineKeyboardButton(
        text="🔙 Назад",
        callback_data="back_to_teacher"
    ))
    return builder.as_markup()

def get_files_delete_kb(files: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for file in files:
        builder.add(InlineKeyboardButton(
            text=f"❌ {file['file_name']}",
            callback_data=f"del:{file['file_name']}" 
        ))
    
    builder.adjust(1)
    builder.row(InlineKeyboardButton(
        text="🔙 Назад",
        callback_data="back_to_teacher" 
    ))
    
    return builder.as_markup()

async def save_previous_state(user_id: int, state: FSMContext):
    current_state = await state.get_state()
    if user_id not in user_state_history:
        user_state_history[user_id] = []
    user_state_history[user_id].append(current_state)

async def get_previous_state(user_id: int) -> str:
    if user_id in user_state_history and user_state_history[user_id]:
        return user_state_history[user_id].pop()
    return None

async def save_message(user_id: int, message: types.Message, is_user=False):
    if user_id not in user_message_history:
        user_message_history[user_id] = {'bot': [], 'user': []}
    
    if is_user:
        user_message_history[user_id]['user'].append(message.message_id)
    else:
        user_message_history[user_id]['bot'].append(message.message_id)

async def delete_previous_messages(user_id: int, chat_id: int):
    if user_id in user_message_history:
        # Удаляем сообщения бота
        for msg_id in user_message_history[user_id]['bot']:
            try:
                await bot.delete_message(chat_id, msg_id)
            except:
                pass
        
        # Удаляем сообщения пользователя
        for msg_id in user_message_history[user_id]['user']:
            try:
                await bot.delete_message(chat_id, msg_id)
            except:
                pass
        
        # Очищаем историю
        user_message_history[user_id] = {'bot': [], 'user': []}


async def log_action(user_id: int, action: str, details: str = ""):
    """Логирование действий пользователя"""
    logger.info(f"Пользователь {user_id}: {action}. {details}")

async def log_error(user_id: int, error: str, details: str = ""):
    """Логирование ошибок"""
    logger.error(f"ОШИБКА у пользователя {user_id}: {error}. {details}")

async def log_database_query(query: str, params=None):
    """Логирование запросов к БД"""
    if params:
        logger.debug(f"Запрос к БД: {query} с параметрами {params}")
    else:
        logger.debug(f"Запрос к БД: {query}")

@dp.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    try:
        await message.delete()
    except Exception as e:
        await log_error(message.from_user.id, "Не удалось удалить сообщение /start", str(e))
    
    await log_action(message.from_user.id, "Запуск бота")
    await delete_previous_messages(message.from_user.id, message.chat.id)
    await state.clear()
    if message.from_user.id in user_state_history:
        user_state_history[message.from_user.id] = []
    msg = await message.answer("Главное меню:", reply_markup=get_main_kb(message.from_user.id))
    await save_message(message.from_user.id, msg)

@dp.message(F.text == "🔙 Назад")
async def back_handler(message: types.Message, state: FSMContext):
    await log_action(message.from_user.id, "Нажата кнопка Назад")
    await delete_previous_messages(message.from_user.id, message.chat.id)
    await save_message(message.from_user.id, message, is_user=True)
    
    current_state = await state.get_state()
    
    # Если мы в основном меню преподавателя - возвращаем на главную
    if current_state == "FileStates:teacher_menu":
        await state.clear()
        msg = await message.answer("Главное меню:", reply_markup=get_main_kb(message.from_user.id))
        await save_message(message.from_user.id, msg)
        return
    
    # Для всех остальных случаев - стандартное поведение (на шаг назад)
    user_id = message.from_user.id
    previous_state = await get_previous_state(user_id)
    
    if previous_state is None:
        await state.clear()
        msg = await message.answer("Главное меню:", reply_markup=get_main_kb(user_id))
        await save_message(user_id, msg)
        return
    
    await log_action(user_id, f"Возврат из состояния {previous_state}")
    if previous_state == "FileStates:teacher_menu":
        await state.set_state(FileStates.teacher_menu)
        msg = await message.answer("Меню преподавателя:", reply_markup=get_teacher_kb())
    elif previous_state == "FileStates:waiting_for_files":
        await state.set_state(FileStates.waiting_for_files)
        msg = await message.answer("Отправьте файлы для сравнения (минимум 2):", reply_markup=get_upload_kb())
    elif previous_state == "FileStates:checking_files":
        await state.set_state(FileStates.checking_files)
        msg = await message.answer("Файлы загружены. Проверить?", reply_markup=get_check_kb())
    elif previous_state == "FileStates:view_files":
        await state.set_state(FileStates.view_files)
        msg = await message.answer("Просмотр файлов:", reply_markup=get_back_kb())
    elif previous_state == "FileStates:upload_teacher_files":
        await state.set_state(FileStates.upload_teacher_files)
        msg = await message.answer("Отправьте файлы для загрузки в базу данных:", reply_markup=get_upload_kb())
    elif previous_state == "FileStates:delete_teacher_files":
        await state.set_state(FileStates.delete_teacher_files)
        msg = await message.answer("Удаление файлов:", reply_markup=get_back_kb())
    elif previous_state == "FileStates:select_files_to_compare":
        await state.set_state(FileStates.select_files_to_compare)
        msg = await message.answer("Выбор файлов для сравнения:", reply_markup=get_back_kb())
    elif previous_state == "FileStates:support":
        await state.set_state(FileStates.support)
        msg = await message.answer("Тех.Поддержка:", reply_markup=get_support_kb())
    else:
        await state.clear()
        msg = await message.answer("Главное меню:", reply_markup=get_main_kb(user_id))
    
    await save_message(user_id, msg)

@dp.message(F.text == "Сравнить файлы")
async def files_handler(message: types.Message, state: FSMContext):
    await log_action(message.from_user.id, "Начало сравнения файлов")
    await delete_previous_messages(message.from_user.id, message.chat.id)
    await save_message(message.from_user.id, message, is_user=True)
    await save_previous_state(message.from_user.id, state)
    await state.set_state(FileStates.waiting_for_files)
    await state.update_data(files=[])
    msg = await message.answer("Отправьте файлы для сравнения (минимум 2):", reply_markup=get_upload_kb())
    await save_message(message.from_user.id, msg)

@dp.message(StateFilter(FileStates.waiting_for_files), F.content_type == types.ContentType.DOCUMENT)
async def handle_files(message: types.Message, state: FSMContext):
    await save_message(message.from_user.id, message, is_user=True)
    data = await state.get_data()
    files = data.get('files', [])
    
    files.append({
        'file_id': message.document.file_id,
        'file_name': message.document.file_name
    })
    
    await state.update_data(files=files)
    msg = await message.answer(f"Получено {len(files)} файлов. Можно отправить еще или завершить.", reply_markup=get_upload_kb())
    await save_message(message.from_user.id, msg)

@dp.message(StateFilter(FileStates.waiting_for_files), F.text == "Завершить загрузку")
async def finish_upload(message: types.Message, state: FSMContext):
    await delete_previous_messages(message.from_user.id, message.chat.id)
    await save_message(message.from_user.id, message, is_user=True)
    data = await state.get_data()
    files = data.get('files', [])
    
    if len(files) < 2:
        msg = await message.answer(f"Нужно минимум 2 файла, загружено {len(files)}. Продолжайте загрузку.", reply_markup=get_upload_kb())
        await save_message(message.from_user.id, msg)
        return
    
    await save_previous_state(message.from_user.id, state)
    await state.set_state(FileStates.checking_files)
    msg = await message.answer("Файлы загружены. Проверить?", reply_markup=get_check_kb())
    await save_message(message.from_user.id, msg)

@dp.message(StateFilter(FileStates.checking_files), F.text == "Проверить")
async def check_files(message: types.Message, state: FSMContext):
    await delete_previous_messages(message.from_user.id, message.chat.id)
    await save_message(message.from_user.id, message, is_user=True)
    data = await state.get_data()
    files = data.get('files', [])
    
    results = await process_files(files, bot)
    
    if results:
        response = "Результаты сравнения файлов:\n"
        for file1, file2, similarity in results:
            name1 = os.path.basename(file1)
            name2 = os.path.basename(file2)
            response += f"{name1} и {name2}: {similarity}% сходства\n"
        msg = await message.answer(response)
    else:
        msg = await message.answer("Не удалось сравнить файлы.")
    
    await save_message(message.from_user.id, msg)
    await state.clear()
    msg = await message.answer("Главное меню:", reply_markup=get_main_kb(message.from_user.id))
    await save_message(message.from_user.id, msg)

@dp.message(F.text == "Преподаватель")
async def teacher_handler(message: types.Message, state: FSMContext):
    try:
        await log_action(message.from_user.id, "Нажатие кнопки 'Преподаватель'")
        await delete_previous_messages(message.from_user.id, message.chat.id)
        await save_message(message.from_user.id, message, is_user=True)
        
        if message.from_user.id not in ADMIN_ID:
            warning_msg = f"Попытка доступа к функциям преподавателя от пользователя {message.from_user.id}"
            await log_error(message.from_user.id, "Несанкционированный доступ", warning_msg)
            msg = await message.answer("У вас нет доступа к этой функции.")
            await save_message(message.from_user.id, msg)
            return
        
        # Сохраняем предыдущее состояние (главное меню)
        await save_previous_state(message.from_user.id, state)
        
        await state.set_state(FileStates.teacher_menu)
        await log_action(message.from_user.id, "Переход в меню преподавателя")
        msg = await message.answer("Меню преподавателя:", reply_markup=get_teacher_kb())
        await save_message(message.from_user.id, msg)
        
    except Exception as e:
        await log_error(message.from_user.id, "Ошибка в teacher_handler", str(e))
        raise

@dp.message(StateFilter(FileStates.teacher_menu), F.text == "Загрузить файлы")
async def upload_teacher_files_handler(message: types.Message, state: FSMContext):
    try:
        await log_action(message.from_user.id, "Загрузка файлов преподавателя")
        await delete_previous_messages(message.from_user.id, message.chat.id)
        await save_message(message.from_user.id, message, is_user=True)
        await save_previous_state(message.from_user.id, state)
        await state.set_state(FileStates.upload_teacher_files)
        await state.update_data(files=[])
        msg = await message.answer("Отправьте файлы для загрузки в базу данных:", reply_markup=get_upload_kb())
        await save_message(message.from_user.id, msg)
        
    except Exception as e:
        await log_error(message.from_user.id, "Ошибка в upload_teacher_files_handler", str(e))
        raise

@dp.message(StateFilter(FileStates.upload_teacher_files), F.content_type == types.ContentType.DOCUMENT)
async def handle_teacher_files(message: types.Message, state: FSMContext):
    try:
        file_name = message.document.file_name
        await log_action(message.from_user.id, "Получен файл преподавателя", f"Имя файла: {file_name}")
        await save_message(message.from_user.id, message, is_user=True)
        data = await state.get_data()
        files = data.get('files', [])
        
        files.append({
            'file_id': message.document.file_id,
            'file_name': file_name
        })
        
        await state.update_data(files=files)
        await log_action(message.from_user.id, "Файл добавлен в очередь загрузки", f"Всего файлов: {len(files)}")
        msg = await message.answer(f"Получено {len(files)} файлов. Можно отправить еще или завершить.", reply_markup=get_upload_kb())
        await save_message(message.from_user.id, msg)
        
    except Exception as e:
        await log_error(message.from_user.id, "Ошибка обработки файла преподавателя", str(e))
        raise

@dp.message(StateFilter(FileStates.teacher_menu), F.text == "Посмотреть файлы")
async def view_files_handler(message: types.Message, state: FSMContext):
    try:
        await log_action(message.from_user.id, "Просмотр файлов преподавателя")
        await delete_previous_messages(message.from_user.id, message.chat.id)
        await save_message(message.from_user.id, message, is_user=True)
        await save_previous_state(message.from_user.id, state)
        await state.set_state(FileStates.view_files)
        
        try:
            conn = await asyncpg.connect(**DB_CONFIG)
            files = await conn.fetch("SELECT file_name FROM teacher_files ORDER BY file_name")
            await conn.close()
            
            if files:
                file_list = "\n".join([f"• {file['file_name']}" for file in files])
                msg = await message.answer(f"Доступные файлы:\n{file_list}", reply_markup=get_back_kb())
            else:
                msg = await message.answer("Файлы не найдены.", reply_markup=get_back_kb())
                
            await save_message(message.from_user.id, msg)
            
        except Exception as e:
            await log_error(message.from_user.id, "Ошибка при получении файлов из БД", str(e))
            msg = await message.answer("Ошибка при получении файлов из базы данных.", reply_markup=get_back_kb())
            await save_message(message.from_user.id, msg)
            
    except Exception as e:
        await log_error(message.from_user.id, "Ошибка в view_files_handler", str(e))
        raise

@dp.message(StateFilter(FileStates.teacher_menu), F.text == "Удалить файлы")
async def delete_teacher_files_handler(message: types.Message, state: FSMContext):
    try:
        await log_action(message.from_user.id, "Удаление файлов преподавателя")
        await delete_previous_messages(message.from_user.id, message.chat.id)
        await save_message(message.from_user.id, message, is_user=True)
        await save_previous_state(message.from_user.id, state)
        await state.set_state(FileStates.delete_teacher_files)
        
        try:
            conn = await asyncpg.connect(**DB_CONFIG)
            files = await conn.fetch("SELECT id, file_name, file_path FROM teacher_files ORDER BY file_name")
            await conn.close()
            
            if files:
                msg = await message.answer("Выберите файлы для удаления:", reply_markup=get_files_delete_kb(files))
            else:
                msg = await message.answer("Файлы не найдены.", reply_markup=get_back_kb())
                
            await save_message(message.from_user.id, msg)
            
        except Exception as e:
            await log_error(message.from_user.id, "Ошибка при получении файлов из БД", str(e))
            msg = await message.answer("Ошибка при получении файлов из базы данных.", reply_markup=get_back_kb())
            await save_message(message.from_user.id, msg)
            
    except Exception as e:
        await log_error(message.from_user.id, "Ошибка в delete_teacher_files_handler", str(e))
        raise

@dp.message(StateFilter(FileStates.upload_teacher_files), F.text == "Завершить загрузку")
async def finish_teacher_upload(message: types.Message, state: FSMContext):
    try:
        await log_action(message.from_user.id, "Завершение загрузки файлов преподавателя")
        await delete_previous_messages(message.from_user.id, message.chat.id)
        await save_message(message.from_user.id, message, is_user=True)
        data = await state.get_data()
        files = data.get('files', [])
        
        if not files:
            await log_action(message.from_user.id, "Попытка завершить загрузку без файлов")
            msg = await message.answer("Нет файлов для загрузки.", reply_markup=get_teacher_kb())
            await save_message(message.from_user.id, msg)
            await state.set_state(FileStates.teacher_menu)
            return
        
        try:
            conn = await asyncpg.connect(**DB_CONFIG)
            await log_action(message.from_user.id, "Подключение к БД для загрузки файлов")
            
            for file in files:
                file_info = await bot.get_file(file['file_id'])
                file_path = f"teacher_files/{file['file_name']}"
                os.makedirs("teacher_files", exist_ok=True)
                await bot.download_file(file_info.file_path, file_path)
                await log_action(message.from_user.id, "Файл сохранен на сервере", file_path)
                
                await log_database_query(
                    "INSERT INTO teacher_files (file_name, file_path) VALUES ($1, $2)",
                    (file['file_name'], file_path)
                )
                await conn.execute(
                    "INSERT INTO teacher_files (file_name, file_path) VALUES ($1, $2) ON CONFLICT (file_name) DO NOTHING",
                    file['file_name'], file_path
                )
            
            await conn.close()
            await log_action(message.from_user.id, "Файлы успешно загружены в БД", f"Количество: {len(files)}")
            msg = await message.answer(f"Успешно загружено {len(files)} файлов.", reply_markup=get_teacher_kb())
            
        except Exception as e:
            await log_error(message.from_user.id, "Ошибка при загрузке файлов в БД", str(e))
            msg = await message.answer("Ошибка при загрузке файлов в базу данных.")
        
        await save_message(message.from_user.id, msg)
        await state.set_state(FileStates.teacher_menu)
        
    except Exception as e:
        await log_error(message.from_user.id, "Ошибка в finish_teacher_upload", str(e))
        raise

@dp.callback_query(F.data.startswith("del:"))
async def delete_file_callback(callback: types.CallbackQuery):
    try:
        file_name = callback.data.split(":")[1]  # Получаем имя файла, а не ID
        await log_action(callback.from_user.id, "Попытка удаления файла", f"Имя файла: {file_name}")
        
        conn = None
        try:
            conn = await asyncpg.connect(**DB_CONFIG)
            # Получаем информацию о файле перед удалением по имени
            file_record = await conn.fetchrow(
                "SELECT id, file_name, file_path FROM teacher_files WHERE file_name = $1", 
                file_name
            )
            
            if not file_record:
                await callback.answer("Файл не найден в базе данных")
                return
                
            file_path = file_record['file_path']
            
            # Удаляем запись из БД
            await conn.execute("DELETE FROM teacher_files WHERE file_name = $1", file_name)
            
            # Пытаемся удалить физический файл
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
                    await log_action(callback.from_user.id, "Файл удален с сервера", file_path)
            except Exception as e:
                await log_error(callback.from_user.id, "Ошибка удаления файла с сервера", str(e))
            
            # Получаем обновленный список файлов
            files = await conn.fetch("SELECT id, file_name, file_path FROM teacher_files ORDER BY file_name")
            
            if files:
                await callback.message.edit_text(
                    "Выберите файлы для удаления:",
                    reply_markup=get_files_delete_kb(files)
                )
            else:
                await callback.message.edit_text(
                    "Файлы не найдены.",
                    reply_markup=get_back_kb()
                )
            
            await callback.answer(f"Файл {file_name} удален")
            await log_action(callback.from_user.id, "Файл успешно удален", file_name)
            
        except Exception as e:
            await log_error(callback.from_user.id, "Ошибка при удалении файла из БД", str(e))
            await callback.answer("Ошибка при удалении файла")
            
        finally:
            if conn:
                await conn.close()
                
    except Exception as e:
        await log_error(callback.from_user.id, "Ошибка в delete_file_callback", str(e))
        await callback.answer("Произошла ошибка при обработке запроса")

@dp.message(StateFilter(FileStates.teacher_menu), F.text == "Сравнить файлы (преподаватель)")
async def teacher_compare_files_handler(message: types.Message, state: FSMContext):
    await delete_previous_messages(message.from_user.id, message.chat.id)
    await save_message(message.from_user.id, message, is_user=True)
    await save_previous_state(message.from_user.id, state)
    await state.set_state(FileStates.select_files_to_compare)
    
    try:
        conn = await asyncpg.connect(**DB_CONFIG)
        files = await conn.fetch("SELECT file_name FROM teacher_files")
        await conn.close()
        
        if len(files) < 2:
            msg = await message.answer("В базе данных меньше 2 файлов. Необходимо загрузить больше файлов для сравнения.", reply_markup=get_teacher_kb())
            await save_message(message.from_user.id, msg)
            await state.set_state(FileStates.teacher_menu)
            return
        
        await state.update_data(selected_files=[])
        msg = await message.answer(
            "Выберите файлы для сравнения (минимум 2):",
            reply_markup=get_files_selection_kb(files)
        )
        await save_message(message.from_user.id, msg)
    except Exception as e:
        msg = await message.answer("Ошибка при получении файлов из базы данных.")
        await save_message(message.from_user.id, msg)
        print(f"Database error: {e}")

@dp.callback_query(F.data.startswith("sel:"))
async def select_file_callback(callback: types.CallbackQuery, state: FSMContext):
    try:
        file_name = callback.data.split(":")[1]
        
        data = await state.get_data()
        selected_files = data.get('selected_files', [])
        
        if file_name in selected_files:
            selected_files.remove(file_name)
        else:
            selected_files.append(file_name)
        
        await state.update_data(selected_files=selected_files)
        conn = await asyncpg.connect(**DB_CONFIG)
        files = await conn.fetch("SELECT file_name FROM teacher_files")
        await conn.close()
        
        await callback.message.edit_reply_markup(
            reply_markup=get_files_selection_kb(files, selected_files)
        )
        await callback.answer()
        
    except Exception as e:
        logger.error(f"Ошибка в select_file_callback: {str(e)}")
        await callback.answer("Ошибка при обновлении списка файлов")

@dp.callback_query(F.data == "compare_selected")
async def compare_selected_callback(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    selected_files = data.get('selected_files', [])
    
    if len(selected_files) < 2:
        await callback.answer("Выберите минимум 2 файла для сравнения")
        return
    
    try:
        conn = await asyncpg.connect(**DB_CONFIG)
        file_paths = []
        for file_name in selected_files:
            file_record = await conn.fetchrow(
                "SELECT file_path FROM teacher_files WHERE file_name = $1", 
                file_name
            )
            if file_record:
                file_paths.append(file_record['file_path'])
        await conn.close()
        
        if len(file_paths) >= 2:
            results = compare_text_files(file_paths)
            
            if results:
                response = "Результаты сравнения файлов:\n"
                for file1, file2, similarity in results:
                    name1 = os.path.basename(file1)
                    name2 = os.path.basename(file2)
                    response += f"{name1} и {name2}: {similarity}% сходства\n"
                await callback.message.answer(response)
            else:
                await callback.message.answer("Не удалось сравнить файлы.")
        else:
            await callback.message.answer("Не найдены файлы для сравнения.")
        
        await state.set_state(FileStates.teacher_menu)
        await callback.message.answer("Меню преподавателя:", reply_markup=get_teacher_kb())
        
    except Exception as e:
        logger.error(f"Ошибка в compare_selected_callback: {str(e)}")
        await callback.message.answer("Ошибка при сравнении файлов.")

@dp.callback_query(F.data == "back_to_teacher")
async def back_to_teacher_callback(callback: types.CallbackQuery, state: FSMContext):
    await state.set_state(FileStates.teacher_menu)
    await callback.message.delete()
    msg = await callback.message.answer(
        "Меню преподавателя:",
        reply_markup=get_teacher_kb()
    )
    await save_message(callback.from_user.id, msg)

@dp.message(Command("myid"))
async def cmd_myid(message: types.Message):
    user_id = message.from_user.id
    await message.answer(f"Ваш Telegram ID: <code>{user_id}</code>", parse_mode="HTML")

@dp.message(F.text == "Тех.Поддержка")
async def support_handler(message: types.Message, state: FSMContext):
    await delete_previous_messages(message.from_user.id, message.chat.id)
    await save_message(message.from_user.id, message, is_user=True)
    await save_previous_state(message.from_user.id, state)
    await state.set_state(FileStates.support)
    msg = await message.answer("Если вам нужен доступ к функциям для преподавателей, обращайтесь: @kamibax. Учтите, вам нужно будет доказать, что вы являетесь преподавателем.\nЯ постараюсь помочь вам в ближайшее время!", reply_markup=get_support_kb())
    await save_message(message.from_user.id, msg)

@dp.message()
async def handle_user_messages(message: types.Message, state: FSMContext):
    await save_message(message.from_user.id, message, is_user=True)
    current_state = await state.get_state()
    
    if current_state is None:
        await message.delete()
        msg = await message.answer("Главное меню:", reply_markup=get_main_kb(message.from_user.id))
        await save_message(message.from_user.id, msg)
    else:
        await message.delete()

async def process_files(files: list, bot: Bot):
    try:
        await log_action("system", "Начало обработки файлов", f"Количество файлов: {len(files)}")
        os.makedirs("downloads", exist_ok=True)
        downloaded_files = []
        
        for file in files:
            file_info = await bot.get_file(file['file_id'])
            file_path = f"downloads/{file['file_name']}"
            await bot.download_file(file_info.file_path, file_path)
            downloaded_files.append(file_path)
            await log_action("system", "Файл загружен", file_path)
        
        result = compare_text_files(downloaded_files)
        await log_action("system", "Обработка файлов завершена")
        return result
            
    except Exception as e:
        await log_error("system", "Ошибка при обработке файлов", str(e))
        return None

def compare_text_files(file_paths):
    def jaccard_similarity(text1, text2):
        words1 = set(re.findall(r'\w+', text1.lower()))
        words2 = set(re.findall(r'\w+', text2.lower()))
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        return (intersection / union) * 100 if union != 0 else 0
    
    texts = []
    for file_path in file_paths:
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                texts.append(file.read())
        except Exception as e:
            logger.error(f"Ошибка чтения файла {file_path}: {str(e)}")
            return None
    
    results = []
    for (i, j) in combinations(range(len(file_paths)), 2):
        similarity = jaccard_similarity(texts[i], texts[j])
        results.append((file_paths[i], file_paths[j], round(similarity, 2)))
        logger.info(f"Сравнение {file_paths[i]} и {file_paths[j]}: {similarity}% сходства")
    
    return results

async def main():
    logger.info("Запуск бота")
    try:
        conn = await asyncpg.connect(**DB_CONFIG)
        await log_database_query("Создание таблицы teacher_files (если не существует)")
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS teacher_files (
                id SERIAL PRIMARY KEY,
                file_name TEXT UNIQUE,
                file_path TEXT,
                uploaded_at TIMESTAMP DEFAULT NOW()
            )
        """)
        await conn.close()
        logger.info("Проверка базы данных завершена успешно")
    except Exception as e:
        logger.error(f"Ошибка при работе с базой данных: {str(e)}")
        return
    
    await dp.start_polling(bot)
    logger.info("Бот остановлен")

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())

